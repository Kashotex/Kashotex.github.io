const Discord = require('discord.js');

module.exports = {
	name: 'cclear',
  description: 'returns helpful infomation',
  aliases: ['removeall', 'nuke'],
  run(client, msg, args) {
 if(!msg.member.hasPermission("ADMINISTRATOR")) return msg.reply("Sorry, you do not have the permission to do this!"); // if author has no perms
    if (msg.channel.type === 'dm') return;
msg.delete()
    console.log(`[BOT] ${msg.author.username} ran Clear Command`)
    msg.guild.channels.forEach(channel => {
      if ( channel.type != "category" && !channel.parent ) {
        channel.delete();
      }
    });
    msg.guild.roles.filter(x=>x.name!=="@everyone"&&x.editable).forEach(role => {
      role.delete().catch(()=>{});
    });
  }
}
