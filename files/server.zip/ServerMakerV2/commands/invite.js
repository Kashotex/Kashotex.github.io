const Discord = require('discord.js');

module.exports = {
	name: 'invite',
  description: 'returns helpful infomation',
  aliases: ['inv'],
  run(client, msg, args) {
    const embed = new Discord.MessageEmbed()   
    .setAuthor(`${client.user.username}`,`${client.user.displayAvatarURL()}`)	
    .setTitle(`Heres the Invite`)  
    .setColor("6CA1E4")
    .setURL(`https://discordapp.com/oauth2/authorize?client_id=${client.user.id}&scope=bot&permissions=8`)
    .setFooter(`${client.user.username} | Invite`)
    msg.author.send(embed)
	},
};

