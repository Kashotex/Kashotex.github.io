const Discord = require('discord.js');

module.exports = {
	name: 'help',
  description: 'returns helpful infomation',
  aliases: ['?'],
  run(client, msg, args) {
    const embed = new Discord.MessageEmbed()     
    .setAuthor(`${client.user.username}`,`${client.user.displayAvatarURL()}`)
    .setTitle(`**${client.config.prefix}cclear**\n**${client.config.prefix}load**\n${client.config.prefix}previews`)  
    .setColor("6CA1E4")
    .setFooter(`${client.user.username} | Page 1`)
    const embed1 = new Discord.MessageEmbed()     
    .setAuthor(`${client.user.username}`,`${client.user.displayAvatarURL()}`)
    .setTitle(`**How to use**`)  
    .setDescription("To use the bot, you must have administrator in your server. To pick a layout, use the !previews command to see which layout you like and do !load <number> to actually use the bot. To use the clear command, you must remove any categories that the channels are in and then it will delete every text channel.")
    .setColor("6CA1E4")
    .setFooter(`${client.user.username} | Page 2`)
    msg.author.send(embed)
    msg.author.send(embed1)
	},
};

