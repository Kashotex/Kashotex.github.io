const Discord = require('discord.js');
const client = new Discord.Client();
const config = require('./config.json');
const Enmap = require("enmap");
const fs = require("fs")

client.config = config;
client.servers = {};

client.on("error", (e) => console.error(e));
client.on("warn", (e) => console.warn(e));

if (config.debug){
  console.log(`[BOT] Debug mode enabled`);
  client.on("debug", (e) => console.info(e));
}
client.on('ready', () => {
client.user.setActivity('!help | Server Maker');
});

process.on('unhandledRejection',  (reason)  => {
  let now = new Date(Date.now());
  console.log('[Bot] Uncaught Promise Rejection at ' + now.toLocaleString("en-US") + '\n' + reason)
});

client.on('ready', () => {
    console.log("[BOT] Ready to make servers!")
});


client.on('message', async message => {
    // Validate that the user can only message the client within a channel on the server
    if (message.author.client) return;
    if (message.channel.type === 'dm') return;

    const messageArray = message.content.split(' ');
    const command = messageArray[0];
    const args = messageArray.slice(1);

    if (!command.startsWith(prefix)) return;

    const cmd = client.commands.get(command.slice(prefix.length));
    if (cmd) cmd.run(client, message, args);
});



fs.readdir("./events/", (err, files) => {
    if (err){
        return console.error(err);
    }
    files.forEach(file => {
      const event = require(`./events/${file}`);
      let eventName = file.split(".")[0];
      client.on(eventName, event.bind(null, client));
    });
  });

client.commands = new Enmap();

fs.readdir("./commands/", (err, files) => {
    if (err){
        return console.error(err);
    }
    files.forEach(file => {
      if (!file.endsWith(".js")){
        return;
      }
      let commandFile = require(`./commands/${file}`);
      let commandName = file.split(".")[0];
      if (client.config.debug){
        console.log("[Bot] Loading " + commandName + ".js")
      }
      client.commands.set(commandName, commandFile);
    });
  });



client.login(config.token);