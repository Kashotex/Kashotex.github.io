THIS IS NOT A RAT!

This is likely KashoMods or Better Discord Downloader or similar sorts. 

DM Kashotex#1634 for more info.