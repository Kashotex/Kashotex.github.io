const Discord = require('discord.js');

module.exports = {
	name: 'previews',
  description: 'returns helpful infomation',
  aliases: ['pre','preview'],
  run(client, msg, args) {
    const loadone = new Discord.MessageEmbed()
        .setTitle("!load 1")
        .setImage("https://i.imgur.com/RBultIO.png")
        .setColor("6CA1E4")
        .setFooter("Basic Server")
    const loadtwo = new Discord.MessageEmbed()
        .setTitle("!load 2")
        .setImage("https://i.imgur.com/DaWZKUC.png")
        .setColor("6CA1E4")
        .setFooter("GFX Server")
    const loadtee = new Discord.MessageEmbed()
        .setTitle("!load 3")
        .setImage("https://i.imgur.com/GiUN5ye.png")
        .setColor("#6CA1E4")
        .setFooter("Gen Server")
    const loadfor = new Discord.MessageEmbed()
        .setTitle("!load 4")
        .setImage("https://i.imgur.com/5l5her0.png")
        .setColor("#6CA1E4")
        .setFooter("Gaming/Clan Server")
    msg.author.send(loadone)
    msg.author.send(loadtwo)
    msg.author.send(loadtee)
    msg.author.send(loadfor)
	},
};

