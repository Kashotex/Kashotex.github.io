module.exports = (client, msg) => {
   
   
    if (msg.content == "plin plin plon"){
        msg.channel.send(":pensive: https://www.youtube.com/watch?v=AB6sOhQan9Y");
    }

    if ((msg.content.indexOf(client.config.prefix) !== 0) || msg.author.bot){
        return;
    }
    const args = msg.content.substring(client.config.prefix.length).split(/ +/g);
    const commandName = args.shift().toLowerCase();
    const  command = client.commands.get(commandName) || client.commands.find(cmd => cmd.aliases && cmd.aliases.includes(commandName));;
    if (client.config.debug){
        console.log("[BOT] Attempting to run command \"" + commandName + "\" with arguments: [" + args + "]")
    }
    if (!command){
        return msg.channel.send('Command not found. Do !help for commands' );
    }
    command.run(client, msg, args);
};