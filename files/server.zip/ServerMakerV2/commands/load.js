const Discord = require('discord.js');

module.exports = {
	name: 'load',
  description: 'returns helpful infomation',
  aliases: ['restore', 'template'],
  run(client, msg, args) {
   if(!msg.member.hasPermission("ADMINISTRATOR")) return msg.reply("Sorry, you do not have the permission to do this!"); // if author has no perms
	if(!args[0]) return msg.channel.send("Please Pick a number between 1 - 4");
          if (msg.channel.type === 'dm') return;
          msg.channel.delete()
	  const amount = parseInt(args[0]);
                 if (isNaN(amount)) {
	       	return msg.channel.send('Please Pick a number between 1 - 4');
	        }
    
	        if (args[0] === '1') {

              msg.author.send("**Running Layout 1**\n`Creating Roles...`\n`Roles Created!`\n`Creating Channels...`\n`Channels Created`\n`Finishing Touches...`\n**Layout 1 Completed!**")
              msg.guild.roles.create({ data: { name: 'Owner', permissions: ['ADMINISTRATOR'], hoist: true, color: '#bf0000' } });
              msg.guild.roles.create({ data: { name: 'Admin', permissions: ['ADMINISTRATOR'], hoist: true, color: '#eea905' } });
              msg.guild.roles.create({ data: { name: 'Moderator', permissions: ['KICK_MEMBERS', 'BAN_MEMBERS' ], hoist: true, color: '#eee405' } });
              msg.guild.roles.create({ data: { name: 'Bots', permissions: ['ADMINISTRATOR'], hoist: true, color: '#9B59B6' } });
              msg.guild.roles.create({ data: { name: 'Members', hoist: true, color: '#7289DA' } });
			  msg.guild.setDefaultMessageNotifications(1);
              msg.guild.roles.get(msg.guild.id).edit({ permissions: ['USE_VAD', 'SEND_MESSAGES', 'VIEW_CHANNEL', 'ADD_REACTIONS', 'ATTACH_FILES', 'CHANGE_NICKNAME', 'SPEAK', 'CONNECT', 'USE_EXTERNAL_EMOJIS', 'READ_MESSAGE_HISTORY', 'CREATE_INSTANT_INVITE'] })    // 'SEND_MESSAGES', 'READ_MESSAGES', 'ADD_REACTIONS', 'ATTACH_FILES', 'CHANGE_NICKNAME', 'SPEAK', 'CONNECT', 'EXTERNAL_EMOJIS'
		msg.guild.channels.create('═════════ INFO ═════════', {
 		 type: 'category',
		  permissionOverwrites: [{
  		   id: msg.guild.id,
 		   deny: ['SEND_MESSAGES'],
 		 }]
		})
	        msg.guild.channels.create("welcome", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '═════════ INFO ═════════'));
                      channel.setTopic("New Members")   
                channel.overwritePermissions({
			          permissionOverwrites: [
                                {
					  id: msg.guild.id,
					  deny: ['SEND_MESSAGES'],
			          }
		              ],
	                })			
                });					  
                

		msg.guild.channels.create("announcements", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '═════════ INFO ═════════'));
                      channel.setTopic("The Announcements for this server.")
					  channel.overwritePermissions({
			          permissionOverwrites: [
                                {
					  id: msg.guild.id,
					  deny: ['SEND_MESSAGES'],
			          }
		              ],
	                })			
                });		
                
		msg.guild.channels.create("rules", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '═════════ INFO ═════════'));
                      channel.setTopic("The Rules for this server. Please read them.")
			          channel.overwritePermissions({
			          permissionOverwrites: [
                                {
					  id: msg.guild.id,
					  deny: ['SEND_MESSAGES'],
			          }
		              ],
	                })			
                });	

		msg.guild.channels.create('═════════ MAIN ═════════', {
 		 type: 'category',
		})
		msg.guild.channels.create("main-chat", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '═════════ MAIN ═════════'));
                      channel.setTopic("The main chat of the guild!")            
                })
		msg.guild.channels.create("bot-spam", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '═════════ MAIN ═════════'));
                      channel.setTopic("Mainly for Bot Commands")               
                })
		msg.guild.channels.create("memes", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '═════════ MAIN ═════════'));
                      channel.setTopic("Memes Channel, Mainly for memes!")               
                })
		msg.guild.channels.create("media", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '═════════ MAIN ═════════'));
                      channel.setTopic("Images or art can go in here!")               
                })
		
		msg.guild.channels.create("nsfw", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '═════════ MAIN ═════════'));
                      channel.setTopic("NSFW Channel, Post weird stuff in here only!")   
                      channel.setNSFW(true, "nsfw channel")					  
                })
	        msg.guild.channels.create("logs", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '═════════ MAIN ═════════'));
                      channel.setTopic("Logs every bot command")   
					  channel.overwritePermissions({
			          permissionOverwrites: [
                                {
					  id: msg.guild.id,
					  deny: ['VIEW_CHANNEL'],
			          }
		              ],
	                });				  
                })
		msg.guild.channels.create('═════════ CALL ═════════', {
 		 type: 'category',
		})
	        msg.guild.channels.create('Call 1', {  type: 'voice' }).then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '═════════ CALL ═════════')); 				  
                })   
	        msg.guild.channels.create('Call 2', {  type: 'voice' }).then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '═════════ CALL ═════════'));  				  
                })
	        msg.guild.channels.create('Call 3', {  type: 'voice' }).then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '═════════ CALL ═════════'));				  
                })
	        msg.guild.channels.create('Call 4', {  type: 'voice' }).then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '═════════ CALL ═════════')); 				  
                })   
               		
	}
	





		if (args[0] === '2') {

              msg.author.send("**Running Layout 2**\n`Creating Roles...`\n`Roles Created!`\n`Creating Channels...`\n`Channels Created`\n`Finishing Touches...`\n**Layout 2 Completed!**")
              msg.guild.roles.create({ data: { name: 'Owner', permissions: ['ADMINISTRATOR'], hoist: true, color: '#ffcd30' } });
              msg.guild.roles.create({ data: { name: 'Admin', permissions: ['ADMINISTRATOR'], hoist: true, color: '#ff8e30' } });
              msg.guild.roles.create({ data: { name: 'Moderator', permissions: ['KICK_MEMBERS', 'BAN_MEMBERS' ], hoist: true, color: '#ff5a30' } });
              msg.guild.roles.create({ data: { name: 'Professional', hoist: true, color: '#a070ff' } });
              msg.guild.roles.create({ data: { name: 'Verified Seller', hoist: true, color: '#7096ff' } });              
              msg.guild.roles.create({ data: { name: 'Mid Tier', hoist: true, color: '#9fb9ff' } });
              msg.guild.roles.create({ data: { name: 'Beginner', hoist: true, color: '#c4d4ff' } });
              msg.guild.roles.create({ data: { name: 'Bots', permissions: ['ADMINISTRATOR'], hoist: true, color: '#9B59B6' } });
              msg.guild.roles.create({ data: { name: 'Members', hoist: true, color: '#5b87ff' } });
			  msg.guild.setDefaultMessageNotifications(1);
              msg.guild.roles.get(msg.guild.id).edit({ permissions: ['USE_VAD', 'SEND_MESSAGES', 'VIEW_CHANNEL', 'ADD_REACTIONS', 'ATTACH_FILES', 'CHANGE_NICKNAME', 'SPEAK', 'CONNECT', 'USE_EXTERNAL_EMOJIS', 'READ_MESSAGE_HISTORY', 'CREATE_INSTANT_INVITE'] })    // 'SEND_MESSAGES', 'READ_MESSAGES', 'ADD_REACTIONS', 'ATTACH_FILES', 'CHANGE_NICKNAME', 'SPEAK', 'CONNECT', 'EXTERNAL_EMOJIS'
		msg.guild.channels.create('💡│Important', {
 		 type: 'category',
		  permissionOverwrites: [{
  		   id: msg.guild.id,
 		   deny: ['SEND_MESSAGES'],
 		 }]
		})
	        msg.guild.channels.create("welcome", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '💡│Important'));
                      channel.setTopic("New Members")      
                channel.overwritePermissions({
			          permissionOverwrites: [
                                {
					  id: msg.guild.id,
					  deny: ['SEND_MESSAGES'],
			          }
		              ],
	                })						  
                });

		msg.guild.channels.create("announcements", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '💡│Important'));
                      channel.setTopic("The Announcements for this server.")
					                  channel.overwritePermissions({
			          permissionOverwrites: [
                                {
					  id: msg.guild.id,
					  deny: ['SEND_MESSAGES'],
			          }
		              ],
	                })	
                });
		msg.guild.channels.create("claim-roles", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '💡│Important'));
                      channel.setTopic("The Rules for this server. Please read them.")
					  channel.overwritePermissions({
			          permissionOverwrites: [
                                {
					  id: msg.guild.id,
					  deny: ['SEND_MESSAGES'],
			          }
		              ],
	                })	

                });
						msg.guild.channels.create("rules", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '💡│Important'));
                      channel.setTopic("The Rules for this server. Please read them.")
					                  channel.overwritePermissions({
			          permissionOverwrites: [
                                {
					  id: msg.guild.id,
					  deny: ['SEND_MESSAGES'],
			          }
		              ],
	                })	

                });
		msg.guild.channels.create('💬│General', {
 		 type: 'category',
		})
		msg.guild.channels.create("lounge", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '💬│General'));
                      channel.setTopic("The main chat of the guild!")            
                })
		msg.guild.channels.create("bot-spam", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '💬│General'));
                      channel.setTopic("Mainly for Bot Commands")               
                })
		msg.guild.channels.create("memes", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '💬│General'));
                      channel.setTopic("Memes Channel, Mainly for memes!")               
                })
		msg.guild.channels.create("media", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '💬│General'));
                      channel.setTopic("Images or art can go in here!")               
                })
		
		msg.guild.channels.create("resources", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '💬│General'));
                      channel.setTopic("Resources for your ART!")   				  
                })
	        msg.guild.channels.create("logs", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '💬│General'));
                      channel.setTopic("Logs every bot command")   
					  channel.overwritePermissions({
			          permissionOverwrites: [
                                {
					  id: msg.guild.id,
					  deny: ['VIEW_CHANNEL'],
			          }
		              ],
	                });				  
                })
		msg.guild.channels.create('✍│Creative Hub', {
 		 type: 'category',
		})
		msg.guild.channels.create("graphic-design", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '✍│Creative Hub'));
                      channel.setTopic("Graphic Design")   				  
                })
		msg.guild.channels.create("photography", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '✍│Creative Hub'));
                      channel.setTopic("Photography")   				  
                })
		msg.guild.channels.create("misc-design", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '✍│Creative Hub'));
                      channel.setTopic("Misc Design")   				  
                })
		msg.guild.channels.create("graphic-help", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '✍│Creative Hub'));
                      channel.setTopic("Design help and support")   				  
                })			
		msg.guild.channels.create('💰│ Marketplace', {
 		 type: 'category',
		})
		msg.guild.channels.create("looking-for", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '💰│ Marketplace'));
                      channel.setTopic("Looking for art or designs")   				  
                })			
		msg.guild.channels.create("selling", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '💰│ Marketplace'));
                      channel.setTopic("Putting out your services")   				  
                })
		msg.guild.channels.create("reviews", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '💰│ Marketplace'));
                      channel.setTopic("How did the service go? 1/10")   				  
                })
		msg.guild.channels.create('🔊 | Voice Channels', {
 		 type: 'category',
		})
	        msg.guild.channels.create('Call 1', {  type: 'voice' }).then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '🔊 | Voice Channels')); 				  
                })  
	        msg.guild.channels.create('Call 2', {  type: 'voice' }).then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '🔊 | Voice Channels')); 				  
                })  
	        msg.guild.channels.create('Call 3', {  type: 'voice' }).then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '🔊 | Voice Channels')); 				  
                })  
	        msg.guild.channels.create('Call 4', {  type: 'voice' }).then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '🔊 | Voice Channels')); 				  
                })  


				
               	
	}
	
		if (args[0] === '3') {

              msg.author.send("**Running Layout 3**\n`Creating Roles...`\n`Roles Created!`\n`Creating Channels...`\n`Channels Created`\n`Finishing Touches...`\n**Layout 3 Completed!**")
              msg.guild.roles.create({ data: { name: 'Owner', permissions: ['ADMINISTRATOR'], hoist: true, color: '#ffcd30' } });
              msg.guild.roles.create({ data: { name: 'Admin', permissions: ['ADMINISTRATOR'], hoist: true, color: '#ff8e30' } });
              msg.guild.roles.create({ data: { name: 'Moderator', permissions: ['KICK_MEMBERS', 'BAN_MEMBERS' ], hoist: true, color: '#ff5a30' } });
			  msg.guild.roles.create({ data: { name: 'Generator Bots', permissions: ['ADMINISTRATOR'], hoist: true, color: '#9B59B6' } });
              msg.guild.roles.create({ data: { name: 'Bots', permissions: ['ADMINISTRATOR'], hoist: true, color: '#9B59B6' } });
              msg.guild.roles.create({ data: { name: 'Members', hoist: true, color: '#5b87ff' } });
			  msg.guild.setDefaultMessageNotifications(1);
              msg.guild.roles.get(msg.guild.id).edit({ permissions: ['USE_VAD', 'SEND_MESSAGES', 'VIEW_CHANNEL', 'ADD_REACTIONS', 'ATTACH_FILES', 'CHANGE_NICKNAME', 'SPEAK', 'CONNECT', 'USE_EXTERNAL_EMOJIS', 'READ_MESSAGE_HISTORY', 'CREATE_INSTANT_INVITE'] })    // 'SEND_MESSAGES', 'READ_MESSAGES', 'ADD_REACTIONS', 'ATTACH_FILES', 'CHANGE_NICKNAME', 'SPEAK', 'CONNECT', 'EXTERNAL_EMOJIS'
		msg.guild.channels.create('══════ IMPORTANT ═══════', {
 		 type: 'category',
		  permissionOverwrites: [{
  		   id: msg.guild.id,
 		   deny: ['SEND_MESSAGES'],
 		 }]
		})
	        msg.guild.channels.create("〘🎁〙welcome", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '══════ IMPORTANT ═══════'));
                      channel.setTopic("New Members")            
                channel.overwritePermissions({
			          permissionOverwrites: [
                                {
					  id: msg.guild.id,
					  deny: ['SEND_MESSAGES'],
			          }
		              ],
	                })			
                });

		msg.guild.channels.create("〘💡〙announcements", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '══════ IMPORTANT ═══════'));
                      channel.setTopic("The Announcements for this server.")
              channel.overwritePermissions({
			          permissionOverwrites: [
                                {
					  id: msg.guild.id,
					  deny: ['SEND_MESSAGES'],
			          }
		              ],
	                })			
                });
		msg.guild.channels.create("〘📃〙suggestions", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '══════ IMPORTANT ═══════'));
                      channel.setTopic("Suggestions for the server")
					  channel.overwritePermissions({
			          permissionOverwrites: [{
					  id: msg.guild.id,
					  allow: ['SEND_MESSAGES'],
			          }]
	          	 })
		});
						msg.guild.channels.create("〘🎉〙giveaways", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '══════ IMPORTANT ═══════'));
                      channel.setTopic("Account Giveaways")
                       channel.overwritePermissions({
			          permissionOverwrites: [
                                {
					  id: msg.guild.id,
					  deny: ['SEND_MESSAGES'],
			          }
		              ],
	                })			

                });

			msg.guild.channels.create('═════════ MAIN ═════════', {
 		             type: 'category',
		             })
		msg.guild.channels.create("〘👋〙main-chat", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '═════════ MAIN ═════════'));
                      channel.setTopic("Images or art can go in here!")               
                })
		
		msg.guild.channels.create("〘🔋〙bot-spam", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '═════════ MAIN ═════════'));
                      channel.setTopic("Resources for your ART!")   				  
                })
		msg.guild.channels.create("〘🎫〙vouches", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '═════════ MAIN ═════════'));
                      channel.setTopic("Resources for your ART!")   				  
                })
		msg.guild.channels.create("〘🎮〙youtube", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '═════════ MAIN ═════════'));
                      channel.setTopic("Resources for your ART!")   				  
                })	    
		msg.guild.channels.create('═══════ GENERATE ═══════', {
 		 type: 'category',
		})
		msg.guild.channels.create("〘📋〙how-to-gen", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '═══════ GENERATE ═══════'));
                      channel.setTopic("How to generate accounts")              
 					  channel.overwritePermissions({
			          permissionOverwrites: [
                                {
					  id: msg.guild.id,
					  deny: ['SEND_MESSAGES'],
			          }
		              ],
	                });				  
                }) 
               
		msg.guild.channels.create("〘🔥〙generator", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '═══════ GENERATE ═══════'));
                      channel.setTopic("Main Generator")   				  
                })
	
		msg.guild.channels.create('═══════ MARKET ════════', {
 		 type: 'category',
		})
		msg.guild.channels.create("〘💳〙looking-for", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '═══════ MARKET ════════'));
                      channel.setTopic("Any Accounts you're looking for?")   				  
                })			
		msg.guild.channels.create("〘💳〙selling", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '═══════ MARKET ════════'));
                      channel.setTopic("Putting out your services / Accounts")   				  
                })
		msg.guild.channels.create("〘🔩〙reviews", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '═══════ MARKET ════════'));
                      channel.setTopic("How did the service go? 1/10")   				  
                })
		msg.guild.channels.create("〘🔩〙report-scammers", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '═══════ MARKET ════════'));
                      channel.setTopic("Let us know if you got scammed!")   				  
                })				
		msg.guild.channels.create('═════════ CALL ═════════', {
 		 type: 'category',
		})
	        msg.guild.channels.create('》 Call 1', {  type: 'voice' }).then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '═════════ CALL ═════════')); 				  
                })  
	        msg.guild.channels.create('》 Call 2', {  type: 'voice' }).then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '═════════ CALL ═════════')); 				  
                })  
	        msg.guild.channels.create('》 Call 3', {  type: 'voice' }).then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '═════════ CALL ═════════')); 				  
                })  
	        msg.guild.channels.create('》 Call 4', {  type: 'voice' }).then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '═════════ CALL ═════════')); 				  
                })  
                		msg.guild.channels.create('════════ STAFF ═════════', {
 		 type: 'category',
		  permissionOverwrites: [{
  		   id: msg.guild.id,
 		   deny: ['VIEW_CHANNEL'],
		  }]
		});
		msg.guild.channels.create("《🔑》 staff-chat", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '════════ STAFF ═════════'));
                      channel.setTopic("For staff only!")   
	  channel.overwritePermissions({
			          permissionOverwrites: [
                                {
					  id: msg.guild.id,
					  deny: ['SEND_MESSAGES'],
			          }
		              ],
	                });			         
                })
		msg.guild.channels.create("《🔑》 bot-cmds", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '════════ STAFF ═════════'));
                      channel.setTopic("Mainly for Staff Bot Commands")   
	  channel.overwritePermissions({
			          permissionOverwrites: [
                                {
					  id: msg.guild.id,
					  deny: ['SEND_MESSAGES'],
			          }
		              ],
	                });			            
                })
		msg.guild.channels.create("《🔑》 logs", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '════════ STAFF ═════════'));
                      channel.setTopic("All bot logs go here!")  
	  channel.overwritePermissions({
			          permissionOverwrites: [
                                {
					  id: msg.guild.id,
					  deny: ['SEND_MESSAGES'],
			          }
		              ],
	                })	
                });		
		}
				
		if (args[0] === '4') {
			             msg.author.send("**Running Layout 1**\n`Creating Roles...`\n`Roles Created!`\n`Creating Channels...`\n`Channels Created`\n`Finishing Touches...`\n**Layout 1 Completed!**")
              msg.guild.roles.create({ data: { name: 'Leader', permissions: ['ADMINISTRATOR'], hoist: true, color: '#bf0000' } });
              msg.guild.roles.create({ data: { name: msg.guild.name, permissions: ['KICK_MEMBERS', 'BAN_MEMBERS' ], hoist: true, color: '#eee405' } });
              msg.guild.roles.create({ data: { name: 'Bots', permissions: ['ADMINISTRATOR'], hoist: true, color: '#9B59B6' } });
              msg.guild.roles.create({ data: { name: 'Members', hoist: true, color: '#7289DA' } });
			  msg.guild.setDefaultMessageNotifications(1);
              msg.guild.roles.get(msg.guild.id).edit({ permissions: ['USE_VAD', 'SEND_MESSAGES', 'VIEW_CHANNEL', 'ADD_REACTIONS', 'ATTACH_FILES', 'CHANGE_NICKNAME', 'SPEAK', 'CONNECT', 'USE_EXTERNAL_EMOJIS', 'READ_MESSAGE_HISTORY', 'CREATE_INSTANT_INVITE'] })    // 'SEND_MESSAGES', 'READ_MESSAGES', 'ADD_REACTIONS', 'ATTACH_FILES', 'CHANGE_NICKNAME', 'SPEAK', 'CONNECT', 'EXTERNAL_EMOJIS'
		msg.guild.channels.create('╠═INFO══╗', {
 		 type: 'category',
		  permissionOverwrites: [{
  		   id: msg.guild.id,
 		   deny: ['SEND_MESSAGES'],
 		 }]
		})

		msg.guild.channels.create("welcome", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '╠═INFO══╗'));
                      channel.setTopic("Welcome to the clan!")
					  channel.overwritePermissions({
			          permissionOverwrites: [
                                {
					  id: msg.guild.id,
					  deny: ['SEND_MESSAGES'],
			          }
		              ],
	                })			
                });	
		msg.guild.channels.create("announcements", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '╠═INFO══╗'));
                      channel.setTopic("The Announcements for this server.")
					  channel.overwritePermissions({
			          permissionOverwrites: [
                                {
					  id: msg.guild.id,
					  deny: ['SEND_MESSAGES'],
			          }
		              ],
	                })			
                });		
		msg.guild.channels.create("requirements", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '╠═INFO══╗'));
                      channel.setTopic("Requirements to join")
					  channel.overwritePermissions({
			          permissionOverwrites: [
                                {
					  id: msg.guild.id,
					  deny: ['SEND_MESSAGES'],
			          }
		              ],
	                })			
                });	
		msg.guild.channels.create("uploads", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '╠═INFO══╗'));
                      channel.setTopic("Clans Youtube Uploads")
					  channel.overwritePermissions({
			          permissionOverwrites: [
                                {
					  id: msg.guild.id,
					  deny: ['SEND_MESSAGES'],
			          }
		              ],
	                })			
                });	
		msg.guild.channels.create("rules", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '╠═INFO══╗'));
                      channel.setTopic("The Announcements for this server.")
					  channel.overwritePermissions({
			          permissionOverwrites: [
                                {
					  id: msg.guild.id,
					  deny: ['SEND_MESSAGES'],
			          }
		              ],
	                })			
                });	
                
		msg.guild.channels.create("gfx", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '╠═INFO══╗'));
                      channel.setTopic("The Rules for this server. Please read them.")
			          channel.overwritePermissions({
			          permissionOverwrites: [
                                {
					  id: msg.guild.id,
					  deny: ['SEND_MESSAGES'],
			          }
		              ],
	                })			
                });	

		msg.guild.channels.create('╠═MAIN══╗', {
 		 type: 'category',
		})
		msg.guild.channels.create("main-chat", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '╠═MAIN══╗'));
                      channel.setTopic("The main chat of the guild!")            
                })
		msg.guild.channels.create("bot-spam", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '╠═MAIN══╗'));
                      channel.setTopic("Mainly for Bot Commands")               
                })
		msg.guild.channels.create("memes", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '╠═MAIN══╗'));
                      channel.setTopic("Memes Channel, Mainly for memes!")               
                })
		msg.guild.channels.create("media", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '╠═MAIN══╗'));
                      channel.setTopic("Images or art can go in here!")               
                })
		
	        msg.guild.channels.create("logs", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '╠═MAIN══╗'));
                      channel.setTopic("Logs every bot command")   
					  channel.overwritePermissions({
			          permissionOverwrites: [
                                {
					  id: msg.guild.id,
					  deny: ['VIEW_CHANNEL'],
			          }
		              ],
	                });				  
                })
		msg.guild.channels.create('╠═JOIN══╗', {
 		 type: 'category',
		})
		msg.guild.channels.create("na-teams", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '╠═JOIN══╗'));
                      channel.setTopic(":flag_us: North American Teams")            
                })
		msg.guild.channels.create("sa-teams", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '╠═JOIN══╗'));
                      channel.setTopic(":flag_sa: South American Teams")               
                })
		msg.guild.channels.create("eu-teams", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '╠═JOIN══╗'));
                      channel.setTopic(":flag_eu: European Teams")               
                })
		msg.guild.channels.create("as-teams", "text").then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '╠═JOIN══╗'));
                      channel.setTopic(":flag_as: Asian Teams")               
                })
				
				
		msg.guild.channels.create('╠═CHAT══╗', {
 		 type: 'category',
		})
	        msg.guild.channels.create('Call 1', {  type: 'voice' }).then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '╠═CHAT══╗')); 				  
                })   
	        msg.guild.channels.create('Call 2', {  type: 'voice' }).then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '╠═CHAT══╗'));  				  
                })
	        msg.guild.channels.create('Call 3', {  type: 'voice' }).then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '╠═CHAT══╗'));				  
                })
	        msg.guild.channels.create('Call 4', {  type: 'voice' }).then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '╠═CHAT══╗')); 				  
                })   
		msg.guild.channels.create('╠═PRVT══╗', {
 		 type: 'category',
		})
	        msg.guild.channels.create('Interviews', {  type: 'voice' }).then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '╠═PRVT══╗')); 		 
					  channel.overwritePermissions({
			          permissionOverwrites: [
                                {
					  id: msg.guild.id,
					  deny: ['VIEW_CHANNEL'],
			          }
		              ],
	                })			  
               				  
                });					                  
	        msg.guild.channels.create('Private Chat', {  type: 'voice' }).then(channel => {
                      channel.setParent(msg.guild.channels.find(c => c.name === '╠═PRVT══╗'));  
					  channel.overwritePermissions({
			          permissionOverwrites: [
                                {
					  id: msg.guild.id,
					  deny: ['VIEW_CHANNEL'],
			          }
		              ],
	                })			  
               				  
                });
               		
	    }
    }
}


				
           
	

    

	
    
	


