const Discord = require('discord.js');

module.exports = {
	name: 'clear',
  description: 'returns helpful infomation',
  aliases: ['restart'],
  run(client, msg, args) {

    msg.author.send("Do the **!cclear** command to remove every channel without a category")
	},
};

